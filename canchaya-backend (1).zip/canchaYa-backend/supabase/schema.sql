-- ═══════════════════════════════════════════════════════════
--  CanchaYa · Schema de base de datos para Supabase
--  Ejecutar en: Supabase Dashboard → SQL Editor → New query
-- ═══════════════════════════════════════════════════════════

-- ── 1. CANCHAS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS canchas (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre      TEXT NOT NULL,
  tipo        TEXT NOT NULL CHECK (tipo IN ('futbol5','futbol7','futbol11')),
  superficie  TEXT DEFAULT 'Césped sintético 4G',
  techada     BOOLEAN DEFAULT false,
  iluminacion BOOLEAN DEFAULT true,
  vestuarios  BOOLEAN DEFAULT false,
  foto_url    TEXT,
  activa      BOOLEAN DEFAULT true,
  creado_en   TIMESTAMPTZ DEFAULT NOW()
);

-- Canchas de ejemplo
INSERT INTO canchas (nombre, tipo, superficie, techada, iluminacion, vestuarios) VALUES
  ('Cancha Élite',   'futbol7',  'Césped sintético 4G premium', true,  true, true),
  ('Cancha Express', 'futbol5',  'Césped sintético 3G',         false, true, false),
  ('Cancha Pro',     'futbol11', 'Césped sintético 4G',         true,  true, true);

-- ── 2. EQUIPOS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS equipos (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre           TEXT NOT NULL,
  capitan          TEXT,
  whatsapp         TEXT NOT NULL UNIQUE,
  modalidad        TEXT NOT NULL CHECK (modalidad IN ('futbol5','futbol7','futbol11')),
  nivel            TEXT NOT NULL CHECK (nivel IN ('Recreativo','Intermedio','Competitivo')),
  ciudad           TEXT NOT NULL DEFAULT 'Villavicencio',
  dias_disponibles TEXT[] DEFAULT '{}',  -- Ej: '{"Lunes","Viernes"}'
  partidos_jugados INTEGER DEFAULT 0,
  activo           BOOLEAN DEFAULT true,
  creado_en        TIMESTAMPTZ DEFAULT NOW()
);

-- ── 3. RESERVAS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reservas (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cancha_id        UUID NOT NULL REFERENCES canchas(id) ON DELETE RESTRICT,
  equipo_id        UUID REFERENCES equipos(id) ON DELETE SET NULL,
  fecha            DATE NOT NULL,
  hora             SMALLINT NOT NULL CHECK (hora BETWEEN 7 AND 21),
  nombre_cliente   TEXT NOT NULL,
  whatsapp_cliente TEXT NOT NULL,
  precio           INTEGER NOT NULL,      -- precio cobrado (dinámico)
  precio_base      INTEGER NOT NULL,      -- precio sin descuento/recargo
  descuento        SMALLINT DEFAULT 0,    -- % de descuento aplicado
  etiqueta_precio  TEXT DEFAULT 'normal', -- oferta | descuento | normal | alta_demanda | pico
  estado           TEXT NOT NULL DEFAULT 'pendiente'
                   CHECK (estado IN ('pendiente','confirmada','cancelada')),
  notas            TEXT,
  creado_en        TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW(),

  -- Evitar doble reserva en mismo turno
  UNIQUE (cancha_id, fecha, hora)
);

-- Índices de búsqueda frecuente
CREATE INDEX IF NOT EXISTS idx_reservas_fecha     ON reservas(fecha);
CREATE INDEX IF NOT EXISTS idx_reservas_cancha    ON reservas(cancha_id, fecha);
CREATE INDEX IF NOT EXISTS idx_reservas_whatsapp  ON reservas(whatsapp_cliente);

-- ── 4. RETOS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS retos (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipo_retador_id UUID NOT NULL REFERENCES equipos(id),
  equipo_rival_id   UUID NOT NULL REFERENCES equipos(id),
  modalidad         TEXT NOT NULL,
  dia               TEXT NOT NULL,
  cancha            TEXT,
  estado            TEXT NOT NULL DEFAULT 'enviado'
                    CHECK (estado IN ('enviado','aceptado','rechazado','jugado')),
  creado_en         TIMESTAMPTZ DEFAULT NOW()
);

-- ── 5. Row Level Security (RLS) ─────────────────────────────
-- Canchas: lectura pública
ALTER TABLE canchas  ENABLE ROW LEVEL SECURITY;
CREATE POLICY "canchas_read_public" ON canchas FOR SELECT USING (true);
CREATE POLICY "canchas_write_admin" ON canchas FOR ALL USING (auth.role() = 'service_role');

-- Reservas: solo el backend (service_role) escribe; lectura restringida
ALTER TABLE reservas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reservas_service" ON reservas FOR ALL USING (auth.role() = 'service_role');

-- Equipos: lectura pública (sin whatsapp), escritura por backend
ALTER TABLE equipos  ENABLE ROW LEVEL SECURITY;
CREATE POLICY "equipos_read_public" ON equipos FOR SELECT USING (true);
CREATE POLICY "equipos_write_service" ON equipos FOR ALL USING (auth.role() = 'service_role');

-- Retos: solo backend
ALTER TABLE retos    ENABLE ROW LEVEL SECURITY;
CREATE POLICY "retos_service" ON retos FOR ALL USING (auth.role() = 'service_role');
